package com.example.lotsizecalculator

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import kotlin.math.abs
import kotlin.math.round

class MainActivity : AppCompatActivity() {
    private lateinit var pairSpinner: Spinner
    private lateinit var entryEditText: EditText
    private lateinit var slEditText: EditText
    private lateinit var riskEditText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var calculateButton: Button
    private lateinit var selectFavoritesButton: Button

    private val favoritePairs = mutableListOf("EURUSD", "GBPUSD", "USDJPY") // default favorites

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        setContentView(R.layout.activity_main)

        pairSpinner = findViewById(R.id.pair_spinner)
        entryEditText = findViewById(R.id.entry_price)
        slEditText = findViewById(R.id.sl_price)
        riskEditText = findViewById(R.id.risk_amount)
        resultTextView = findViewById(R.id.result_text)
        calculateButton = findViewById(R.id.calculate_button)
        selectFavoritesButton = findViewById(R.id.select_favorites_button)

        loadFavorites()
        setupSpinner()

        calculateButton.setOnClickListener {
            calculateLotSize()
        }

        selectFavoritesButton.setOnClickListener {
            startActivity(Intent(this, SelectFavoritesActivity::class.java))
        }
    }

    private fun setupSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, favoritePairs)
        pairSpinner.adapter = adapter
    }

    private fun loadFavorites() {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        val set = prefs.getStringSet("favorites", null)
        set?.let {
            favoritePairs.clear()
            favoritePairs.addAll(it)
        }
    }

    private fun calculateLotSize() {
        val pair = pairSpinner.selectedItem.toString()
        val entry = entryEditText.text.toString().toDoubleOrNull()
        val sl = slEditText.text.toString().toDoubleOrNull()
        val risk = riskEditText.text.toString().toDoubleOrNull()

        if (entry == null || sl == null || risk == null) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            return
        }

        val pipSize = if (pair.contains("JPY")) 0.01 else 0.0001
        val pips = abs(entry - sl) / pipSize
        val costPerLot = pips * 10
        val rawLotSize = risk / costPerLot
        val lotSizeRounded = round(rawLotSize * 100) / 100.0

        resultTextView.text = "Recommended Lot Size: $lotSizeRounded"
    }
}