package com.example.lotsizecalculator

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SelectFavoritesActivity : AppCompatActivity() {

    private val allPairs = listOf(
        "EURUSD", "GBPUSD", "AUDUSD", "NZDUSD",
        "GBPJPY", "AUDJPY", "NZDJPY", "USDJPY",
        "XAUUSD", "XAGUSD", "NAS100", "WTI Crude"
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var listView: ListView
    private lateinit var saveButton: Button
    private val selectedPairs = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_favorites)

        prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        listView = findViewById(R.id.pair_list_view)
        saveButton = findViewById(R.id.save_button)

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, allPairs)
        listView.adapter = adapter
        listView.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        // Load existing favorites
        val savedFavorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        for (i in allPairs.indices) {
            if (allPairs[i] in savedFavorites) {
                listView.setItemChecked(i, true)
                selectedPairs.add(allPairs[i])
            }
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val pair = allPairs[position]
            if (selectedPairs.contains(pair)) {
                selectedPairs.remove(pair)
            } else {
                if (selectedPairs.size >= 5) {
                    Toast.makeText(this, "Max 5 pairs allowed", Toast.LENGTH_SHORT).show()
                    listView.setItemChecked(position, false)
                } else {
                    selectedPairs.add(pair)
                }
            }
        }

        saveButton.setOnClickListener {
            prefs.edit().putStringSet("favorites", selectedPairs).apply()
            Toast.makeText(this, "Favorites saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}